---
name: User story
about: Use this template for user stories.
title: "[Epic]: User story"
labels: user story
---

# Epic

Include the issue that represents the epic.

# Functional

Please explain in detail the functionality.
Please also include relevant motivation and context.

## Schema

### Tech

- [] To-do

### Tests

- [] it ...

### Validation Checks

- [] it ...
