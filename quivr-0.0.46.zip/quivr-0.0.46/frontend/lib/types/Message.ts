export type Message = {
  type: "success" | "error" | "warning";
  text: string;
};
