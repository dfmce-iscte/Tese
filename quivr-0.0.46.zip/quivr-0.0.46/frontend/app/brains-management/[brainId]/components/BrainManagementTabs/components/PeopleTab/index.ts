export * from "./PeopleTab";
