export type BrainManagementTab = "settings" | "people" | "knowledge";
